OneHundo Linux x86_64 Release Bundle (v0.1.0)
==================================================

Contents:
  - onehundod                         Local achievement daemon (static musl x86_64)
  - onehundo-desktop                  Desktop service & Game Health CLI (static musl x86_64)
  - packs/*.onehundo                  Bundled achievement packs (28 packs)
  - deploy/systemd/onehundod.service  systemd --user service unit
  - install.sh                        Installer script (~/.local/bin + packs + systemd unit)

Quick Install:
  tar -xzf onehundo-linux-x86_64.tar.gz && ./install.sh

  (Or extract into a subfolder first:
   mkdir -p onehundo-linux-x86_64 && tar -xzf onehundo-linux-x86_64.tar.gz -C onehundo-linux-x86_64 && cd onehundo-linux-x86_64 && ./install.sh)

Runtime Notes:
  - Both binaries are statically linked (zero glibc runtime dependency).
  - HTTPS cloud sync uses the system `curl` CLI when syncing with https://onehundo.org.
  - Desktop unlock notifications use `notify-send` (libnotify) when available.
  - Generate a daemon API key in your OneHundo account page, then run:
      ~/.local/bin/onehundo-desktop set-api-key <oh_live_...>
  - Local Game Health dashboard runs at: http://127.0.0.1:19850
