#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN_DIR="${HOME}/.local/bin"
DATA_DIR="${XDG_DATA_HOME:-${HOME}/.local/share}/onehundo"
PACKS_DIR="${DATA_DIR}/packs"
SYSTEMD_USER_DIR="${XDG_CONFIG_HOME:-${HOME}/.config}/systemd/user"

mkdir -p "${BIN_DIR}" "${PACKS_DIR}" "${SYSTEMD_USER_DIR}"

install -m 0755 "${SCRIPT_DIR}/onehundod" "${BIN_DIR}/onehundod"
install -m 0755 "${SCRIPT_DIR}/onehundo-desktop" "${BIN_DIR}/onehundo-desktop"

if compgen -G "${SCRIPT_DIR}/packs/*.onehundo" >/dev/null; then
  install -m 0644 "${SCRIPT_DIR}/packs/"*.onehundo "${PACKS_DIR}/"
fi

install -m 0644 "${SCRIPT_DIR}/deploy/systemd/onehundod.service" "${SYSTEMD_USER_DIR}/onehundod.service"

echo "Installed binaries to ${BIN_DIR}/onehundod and ${BIN_DIR}/onehundo-desktop"
echo "Installed packs to ${PACKS_DIR}"
echo "Installed systemd user unit to ${SYSTEMD_USER_DIR}/onehundod.service"

if command -v systemctl >/dev/null 2>&1 && systemctl --user show-environment >/dev/null 2>&1; then
  systemctl --user daemon-reload
  systemctl --user enable --now onehundod.service
  systemctl --user restart onehundod.service || true
  echo "Enabled and started onehundod.service via systemd --user"
else
  echo "Note: systemd --user session is not active; skipped automatic unit enable."
  echo "Enable manually later with: systemctl --user enable --now onehundod.service"
  echo "Or start directly with: ${BIN_DIR}/onehundo-desktop start"
fi

case ":${PATH}:" in
  *":${BIN_DIR}:"*) ;;
  *)
    echo ""
    echo "Add ${BIN_DIR} to your PATH to run onehundod / onehundo-desktop directly:"
    echo "  export PATH=\"${BIN_DIR}:\$PATH\""
    ;;
esac

echo ""
echo "Next steps:"
echo "  1. Check daemon status: ${BIN_DIR}/onehundo-desktop status"
echo "  2. Open Game Health UI: http://127.0.0.1:19850"
echo "  3. Set your sync key:   ${BIN_DIR}/onehundo-desktop set-api-key <oh_live_...>"
